@echo off
setlocal
cd /d "%~dp0"

set ONLINE_URL=https://www.miruo.com.tr/app/

:: Try Microsoft Edge App Mode
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="%ONLINE_URL%" --window-size=1280,820
    exit /b
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app="%ONLINE_URL%" --window-size=1280,820
    exit /b
)

:: Try Google Chrome App Mode
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="%ONLINE_URL%" --window-size=1280,820
    exit /b
)
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --app="%ONLINE_URL%" --window-size=1280,820
    exit /b
)

:: Default browser fallback
start "" "%ONLINE_URL%"
