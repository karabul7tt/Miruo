===================================================
MIRUO WATCH PARTY — WINDOWS DESKTOP
===================================================

Miruo'yu Windows bilgisayarınızda çalıştırmak için:

1) "Miruo-Windows-Setup.exe" veya "Miruo.cmd" dosyasına çift tıklayın.
   Uygulama pencereli masaüstü modunda anında açılacaktır.

2) Masaüstünüze tek tıkla kısayol eklemek için:
   "Kurulum-ve-Kisayol-Olustur.bat" dosyasına çift tıklayın.

İyi seyirler!
