@echo off
setlocal
cd /d "%~dp0"

echo ===================================================
echo        Miruo Masaustu Kisayolu Olusturuluyor...
echo ===================================================

set SCRIPT_DIR=%~dp0
set TARGET=%SCRIPT_DIR%Miruo.vbs
set ICON=%SCRIPT_DIR%Miruo.ico

powershell -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([System.IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), 'Miruo.lnk')); $s.TargetPath = '%TARGET%'; $s.IconLocation = '%ICON%'; $s.WorkingDirectory = '%SCRIPT_DIR%'; $s.Save()"

echo.
echo [OK] Masaustune 'Miruo' kisayolu basariyla eklendi!
echo Cift tiklayarak hemen baslatabilirsiniz.
echo.
pause
